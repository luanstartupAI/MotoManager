<?php

namespace App\Filament\Resources\AppraisalItemResource\Pages;

use App\Filament\Resources\AppraisalItemResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAppraisalItem extends CreateRecord
{
    protected static string $resource = AppraisalItemResource::class;
}
