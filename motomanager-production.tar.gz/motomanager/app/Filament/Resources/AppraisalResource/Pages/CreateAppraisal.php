<?php

namespace App\Filament\Resources\AppraisalResource\Pages;

use App\Filament\Resources\AppraisalResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAppraisal extends CreateRecord
{
    protected static string $resource = AppraisalResource::class;
}
