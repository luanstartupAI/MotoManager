<?php

namespace App\Filament\Resources\LeadOriginResource\Pages;

use App\Filament\Resources\LeadOriginResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLeadOrigin extends CreateRecord
{
    protected static string $resource = LeadOriginResource::class;
}
